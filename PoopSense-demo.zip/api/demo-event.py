"""Vercel serverless endpoint for the PoopSense BME688 demo event."""

import json
import sys
from http.server import BaseHTTPRequestHandler
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import load_demo


class handler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        try:
            payload = load_demo()
            status = 200
        except Exception as error:  # Vercel must always return JSON to the UI.
            payload = {"status": "error", "message": str(error)}
            status = 500

        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)
