#!/usr/bin/env python3
"""PoopSense (便知) zero-dependency sensor demo server."""

from __future__ import annotations

import json
import statistics
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DEMO_DATA = ROOT / "data" / "bme688-demo.bmerawdata"


def classify_bme688(payload: dict[str, Any]) -> dict[str, Any]:
    body = payload["rawDataBody"]
    keys = [column["key"] for column in body["dataColumns"]]
    rows = [dict(zip(keys, values)) for values in body["dataBlock"]]
    if not rows:
        raise ValueError("BME688 dataBlock is empty")

    resistances = [float(row["resistance_gassensor"]) for row in rows]
    temperatures = [float(row["temperature"]) for row in rows]
    humidity = [float(row["relative_humidity"]) for row in rows]
    errors = [row for row in rows if int(row["error_code"]) != 0]
    cycles = len({int(row["scanning_cycle_index"]) for row in rows})
    minimum = min(resistances)
    baseline = statistics.median(resistances)
    change_pct = max(0.0, (baseline - minimum) / baseline * 100.0)

    return {
        "event_id": "evt_demo_bme688_001",
        "member_id": "member_alex",
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "status": "complete",
        "classification": {
            "bristol": {"type": 4, "confidence": 0.86, "source": "demo_simulation"},
            "color": {"category": "brown_like", "confidence": 0.82, "source": "demo_simulation"},
            "odor": {
                "intensity": "medium" if change_pct >= 45 else "low",
                "minimum_gas_resistance_ohm": round(minimum, 2),
                "baseline_gas_resistance_ohm": round(baseline, 2),
                "change_pct": round(change_pct, 1),
                "confidence": 0.71,
                "source": "bme688_raw_data",
            },
        },
        "environment": {
            "temperature_c": round(statistics.mean(temperatures), 2),
            "humidity_pct": round(statistics.mean(humidity), 2),
        },
        "quality": {
            "status": "valid" if not errors else "partial",
            "record_count": len(rows),
            "scanning_cycles": cycles,
            "sensor_error_count": len(errors),
        },
        "risk_rules": {"level": "none", "triggered_rules": [], "requires_urgent_message": False},
        "model_versions": {
            "odor_classifier": "demo-feature-v1",
            "bristol_classifier": "demo-simulated-v1",
            "color_classifier": "demo-simulated-v1",
        },
    }


def load_demo() -> dict[str, Any]:
    with DEMO_DATA.open("r", encoding="utf-8") as handle:
        return classify_bme688(json.load(handle))


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/api/health":
            self._json(200, {"status": "online", "device_id": "toilet_001", "demo": True})
            return
        if self.path == "/api/demo-event":
            try:
                self._json(200, load_demo())
            except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
                self._json(500, {"status": "error", "message": str(error)})
            return
        super().do_GET()

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/api/events":
            self._json(404, {"status": "error", "message": "unknown endpoint"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            incoming = json.loads(self.rfile.read(length) or b"{}")
            self._json(201, classify_bme688(incoming))
        except (ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
            self._json(400, {"status": "error", "message": str(error)})


if __name__ == "__main__":
    print("PoopSense Demo: http://localhost:8080")
    ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
